﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using mohd.Models;
using mohd.Models.Data;

namespace mohd.Controllers
{
    public class StudentController : Controller
    {
        // GET: StudentController
        DataContext dbclass;
        public StudentController(DataContext DBContext)
        {
            dbclass = DBContext;
        }
        public ActionResult StudentData()
        {
            var stu = dbclass.Students.ToList();
            return View(stu);
        }

        // GET: StudentController/Create
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentController/Create
        [HttpPost]
        public ActionResult AddNew(StudentModel st)
        {
            dbclass.Students.Add(st);
            dbclass.SaveChanges();
            return RedirectToAction("StudentData");
        }

        

        // GET: StudentController/Edit/5
        public ActionResult Edit(int id)
        {
            var stu = dbclass.Students.SingleOrDefault(s => s.id == id);
            return View(stu);
        }

        // POST: StudentController/Edit/5
        [HttpPost]
        public ActionResult Edit(StudentModel ed)
        {
            dbclass.Students.Update(ed);
            dbclass.SaveChanges();
            return RedirectToAction("StudentData");
        }

        // GET: StudentController/Delete/5
        public ActionResult Delete(int Id)
        {
            var sd = dbclass.Students.SingleOrDefault(s => s.id == Id);
            dbclass.Students.Remove(sd);
            dbclass.SaveChanges();
            return RedirectToAction("StudentData");
            
        }
    }
}